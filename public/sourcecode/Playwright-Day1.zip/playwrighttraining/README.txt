Playwright Masterclass

Day1

Commands

npm install

npx playwright install

npx playwright test

website

https://practicaltechlab.vercel.app

Happy Learning!