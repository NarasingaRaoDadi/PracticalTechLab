Playwright Masterclass

Day3

    Introduction

    What is locators and Web Elements

    Create test - Day3.locators.spec.ts

    Inspecting Elements on website

    Copying CSS selectors and Xpath

    identyfying getByPlaceholder locator to fill Email in Email text box in login page

    identyfying getByRole locator for forgot password button in login page

    identyfying getByText locator for Create Account button in login page

    identyfying css selector locator for login button in sign up page

    identyfying xpath locator to fill password text box in login page

Script-   

Locators Test Flow-

    //navigating to Practical Tech Lab login page
    await page.goto('https://practicaltechlab.vercel.app/login');

  //first locator test - getByPlaceholder
  await page.getByPlaceholder('Email').fill('practicaltechlab@gmail.com');

  //second locator test - getByRole
  await page.getByRole('button', {name: 'Forgot Password?'}).click();

  //third locator test - getByText
  await page.getByText('Create Account').click();

  //fourth locator test - css selector - locator - clicking login button
  await page.locator('#root > div > form > button:nth-child(8)').click();

  //fifth locator test - xpath - clicking on passowrd and fill the password field.
  await page.locator('//*[@id="root"]/div/form/input[2]').fill('practcial');
  

commands-
    npx Playwright test

    npx Playwright show-report

    npx playwright test --ui

Happy Learning!