import {test} from '@playwright/test';

test('loators testing', async ({ page }) => {
  await page.goto('https://practicaltechlab.vercel.app/login');

  //first locator test - getByPlaceholder
  await page.getByPlaceholder('Email').fill('practicaltechlab@gmail.com');

  //second locator test - getByRole
  await page.getByRole('button', {name: 'Forgot Password?'}).click();

  //third locator test - getByText
  await page.getByText('Create Account').click();

  //fourth locator test - css selector - locator - clicking login button
  await page.locator('#root > div > form > button:nth-child(8)').click();

  //fifth locator test - xpath - clicking on passowrd and fill the password field.
  await page.locator('//*[@id="root"]/div/form/input[2]').fill('practcial');
  
});
