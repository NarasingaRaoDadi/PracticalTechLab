Playwright Masterclass

Day2

Test Structure
    Import
    test
    expect
    page
    async
    await

First Test Flow-
    //navigating to website - Practical Tech Lab
    await page.goto('https://practicaltechlab.vercel.app/');

    //validate the title
    await expect(page).toHaveTitle(/Practical/);

    //validate the url of the website
    await expect(page).toHaveURL('https://practicaltechlab.vercel.app/');

    //capture screen shot
    await page.screenshot({path: 'day2.png'});

commands-
    npx Playwright test

    npx Playwright show-report

Happy Learning!