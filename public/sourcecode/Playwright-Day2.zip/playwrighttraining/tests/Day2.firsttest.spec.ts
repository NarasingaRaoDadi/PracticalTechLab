import {test, expect} from '@playwright/test';
test('navigating website', async ({ page }) => {

    //navigating to website - practival tech lab- test case- step1
    await page.goto('https://practicaltechlab.vercel.app/');

    //validate the title
    await expect(page).toHaveTitle(/Practical/);

    //validate the url of the website

    await expect(page).toHaveURL('https://practicaltechlab.vercel.app/');

    //capture screen shot
    await page.screenshot({path: 'day2.png'});



  
});
