import {test, expect} from '@playwright/test';
test('assertions testing', async ({ page }) => {
  await page.goto('https://practicaltechlab.vercel.app/');

  //first assertion - toHaveTitle
  await expect(page).toHaveTitle(/Practical/);

  //second assertion - toHaveURL
  await expect(page).toHaveURL('https://practicaltechlab.vercel.app/');

  //third assertion - toHaveText
  await expect(page.getByText('Student Login')).toHaveText(/Student/);

  //fourth assertion - toContainText
  await expect(page.locator('body')).toContainText('Automation');

  //fifth assertion -toBeEnabled
  //Action
  await page.getByRole('button', {name: 'FREE MODULE AVAILABLE'}).click();
  //Assertion
  await expect(page.getByRole('button', {name: '▶ Watch Free Lesson'})).toBeEnabled();

  //sixth Assertion - toBeDisabled
  await expect(page.locator('//*[@id="root"]/section/div[2]/div[3]/button')).toBeDisabled();


  
});
